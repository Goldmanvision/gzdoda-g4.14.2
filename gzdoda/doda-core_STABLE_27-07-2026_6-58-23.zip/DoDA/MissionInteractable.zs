/*//////////////////////////|
// DoDA/MissionInteractable.zs
*///////////////////////////|

class DoDAMissionInteractable : Actor
{
    bool Activated;

    Default
    {
        Radius 16;
        Height 32;

        +SOLID;
        +USESPECIAL;
    }

    override bool Used(Actor user)
    {
        if (user == null)
        {
            return false;
        }

        DoDACampaignState campaignState =
            DoDACampaignState(user.FindInventory("DoDACampaignState"));

        if (campaignState == null)
        {
            Console.Printf("DoDA: CampaignState not found for mission interactable.");
            return false;
        }

        if (level.MapName != "MAP01" || campaignState.GetNextMissionIndex() != 0)
        {
            Console.MidPrint(
                Font.GetFont("SmallFont"),
                "$DODA_INACTIVE_OBJECTIVE",
                true
            );

            Console.Printf(
                "DoDA: Mission interactable inactive. Map=%s NextMissionIndex=%d",
                level.MapName,
                campaignState.GetNextMissionIndex()
            );
            return false;
        }

        if (Activated)
        {
            return false;
        }

        Activated = true;
        Console.Printf("DoDA: Mission interactable used.");

        DoDAMissionDirector director =
            DoDAMissionDirector(EventHandler.Find("DoDAMissionDirector"));

        if (director == null)
        {
            Console.Printf("DoDA: MissionDirector not found for mission interactable.");
            return false;
        }

        director.CompleteMission();

        Console.MidPrint(
            Font.GetFont("SmallFont"),
            "$DODA_MISSION_COMPLETE",
            true
        );

        Console.Printf("DoDA: MissionDirector mission status updated.");
        SetStateLabel("Activated");
        return true;
    }

    States
    {
    Spawn:
        PLAY E -1;
        Stop;

    Activated:
        PLAY B -1;
        Stop;
    }
}
