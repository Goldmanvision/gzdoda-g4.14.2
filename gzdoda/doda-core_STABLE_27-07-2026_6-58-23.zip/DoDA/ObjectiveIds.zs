/*//////////////////////////|
// DoDA/ObjectiveIds.zs
*///////////////////////////|

enum EDoDAObjectiveId
{
    DODInvalid = -1,
    DODInformant,
    DODTerminal,
    DODSecondaryFile
}