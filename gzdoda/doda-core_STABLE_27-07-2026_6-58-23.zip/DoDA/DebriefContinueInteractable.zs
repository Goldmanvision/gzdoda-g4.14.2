/*//////////////////////////|
// DoDA/DebriefContinueInteractable.zs
*///////////////////////////|

class DoDADebriefContinueInteractable : Actor
{
    bool Activated;

    Default
    {
        Radius 16;
        Height 32;

        +SOLID;
        +USESPECIAL;
    }

    override bool Used(Actor user)
    {
        if (user == null)
        {
            return false;
        }

        if (Activated)
        {
            return false;
        }

        Activated = true;

        DoDALastMissionReport report =
            DoDALastMissionReport(
                user.FindInventory("DoDALastMissionReport")
            );

        if (report != null)
        {
            report.ClearReport();
        }
        else
        {
            Console.Printf("DoDA: No LastMissionReport found to clear on return to field.");
        }

        DoDACampaignState campaignState =
            DoDACampaignState(
                user.FindInventory("DoDACampaignState")
            );

        if (campaignState == null)
        {
            user.GiveInventory("DoDACampaignState", 1);

            campaignState = DoDACampaignState(
                user.FindInventory("DoDACampaignState")
            );
        }

        if (campaignState != null)
        {
            campaignState.AdvanceToNextMission();
        }
        else
        {
            Console.Printf("DoDA: CampaignState not found during mission advance.");
        }

        Console.MidPrint(
            Font.GetFont("DoDAPalmFont"),
            "$DODA_RETURNING_TO_FIELD",
            true
        );

        Console.Printf("DoDA: Returning to field.");
        SetStateLabel("Activated");
        return true;
    }

    States
    {
    Spawn:
        DDEB A -1;
        Stop;

    Activated:
        DDEB B 100;
        TNT1 A 0
        {
            level.ChangeLevel("MAP01");
        }
        Stop;
    }
}