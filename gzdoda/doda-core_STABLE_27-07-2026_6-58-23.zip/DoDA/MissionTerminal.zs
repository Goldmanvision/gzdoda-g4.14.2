/*//////////////////////////|
// DoDA/MissionTerminal.zs
*///////////////////////////|

class DoDAMissionTerminal : Actor
{
    bool Activated;

    Default
    {
        Radius 16;
        Height 32;

        +SOLID;
        +USESPECIAL;
    }

    override bool Used(Actor user)
    {
        if (user == null)
        {
            return false;
        }

        DoDACampaignState campaignState =
            DoDACampaignState(user.FindInventory("DoDACampaignState"));

        if (campaignState == null)
        {
            Console.Printf("DoDA: CampaignState not found for mission terminal.");
            return false;
        }

        if (level.MapName != "MAP01" || campaignState.GetNextMissionIndex() != 1)
        {
            Console.MidPrint(
                Font.GetFont("SmallFont"),
                "$DODA_TERMINAL_INACTIVE",
                true
            );

            Console.Printf(
                "DoDA: Terminal inactive for mission index %d.",
                campaignState.GetNextMissionIndex()
            );
            return false;
        }

        if (Activated)
        {
            return false;
        }

        Activated = true;
        Console.Printf("DoDA: Mission terminal used.");

        DoDAMissionDirector director =
            DoDAMissionDirector(EventHandler.Find("DoDAMissionDirector"));

        if (director == null)
        {
            Console.Printf("DoDA: MissionDirector not found for mission terminal.");
            return false;
        }

        director.CompleteMission();

        Console.MidPrint(
            Font.GetFont("SmallFont"),
            "$DODA_TERMINAL_DATA_RECORDED",
            true
        );

        SetStateLabel("Activated");
        return true;
    }

    States
    {
    Spawn:
        PMAP A -1;
        Stop;

    Activated:
        PMAP B 18;
        PMAP C -1;
        Stop;
    }
}