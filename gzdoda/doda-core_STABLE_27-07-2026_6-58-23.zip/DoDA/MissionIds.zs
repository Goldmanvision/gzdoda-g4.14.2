/*//////////////////////////|
// DoDA/MissionIds.zs
*///////////////////////////|

enum EDoDAMissionId
{
    DMDInvalid = -1,
    DMDMission01,
    DMDMission02,
    DMDMission03
}