/*//////////////////////////|
// DoDA/MissionTerminal.zs
*///////////////////////////|

class DoDAMissionTerminal : Actor
{
    bool Activated;

    Default
    {
        Radius 16;
        Height 32;

        +SOLID;
        +USESPECIAL;
    }

    override bool Used(Actor user)
    {
        if (user == null)
        {
            return false;
        }

        DoDAMissionDirector director =
            DoDAMissionDirector(EventHandler.Find("DoDAMissionDirector"));

        if (director == null)
        {
            Console.Printf("DoDA: MissionDirector not found for terminal use.");
            return false;
        }

        if (director.GetMissionIndex() != 1)
        {
            Console.MidPrint(
                Font.GetFont("SmallFont"),
                "$DODA_TERMINAL_INACTIVE",
                true
            );

            Console.Printf(
                "DoDA: Terminal inactive for mission index %d.",
                director.GetMissionIndex()
            );
            return false;
        }

        if (Activated)
        {
            return false;
        }

        Activated = true;

        Console.Printf("DoDA: Mission terminal used.");
        director.CompleteMission();

        Console.MidPrint(
            Font.GetFont("SmallFont"),
            "$DODA_TERMINAL_DATA_RECORDED",
            true
        );

        return true;
    }

    States
    {
    Spawn:
        TMAP A -1;
        Stop;

    Activated:
        TMAP B 18;
        TMAP C -1;
        Stop;
    }
}