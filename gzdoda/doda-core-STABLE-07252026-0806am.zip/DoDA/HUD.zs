/*//////////////////////////|
// DoDA/HUD.zs
*///////////////////////////|

class DoDAHUD : BaseStatusBar
{
    override void Draw(int state, double TicFrac)
    {
        Super.Draw(state, TicFrac);

        Font font = Font.GetFont("DoDAPalmFont");
        int black = Font.FindFontColor("Black");

        String titleText = "FBI: DODA TAPLINE CONNECTED";
        String missionText = "MISSION: UNKNOWN";
        String statusText = "STATUS: UNKNOWN";
        String progressText = "PROGRESS: 0%";
        String phaseText = "PHASE: UNKNOWN";

        DoDAMissionDirector director =
            DoDAMissionDirector(EventHandler.Find("DoDAMissionDirector"));

        if (director != null)
        {
            missionText = "MISSION: " .. director.GetMissionName();
            progressText = "PROGRESS: " .. director.GetMissionPercentComplete() .. "%";

            switch (director.GetMissionResult())
            {
            case MISSION_PENDING:
                statusText = "STATUS: PENDING";
                break;

            case MISSION_IN_PROGRESS:
                statusText = "STATUS: IN PROGRESS";
                break;

            case MISSION_SUCCESS:
                statusText = "STATUS: SUCCESS";
                break;

            case MISSION_FAILURE:
                statusText = "STATUS: FAILURE";
                break;

            case MISSION_ABORTED:
                statusText = "STATUS: ABORTED";
                break;
            }

            switch (director.GetMissionPhase())
            {
            case 1:
                phaseText = "PHASE: OBJECTIVE";
                break;

            case 2:
                phaseText = "PHASE: EXTRACTION";
                break;

            default:
                phaseText = "PHASE: UNKNOWN";
                break;
            }
        }

        int panelWidth = 520;
        int panelHeight = 190;
        int margin = 24;
        int padding = 16;
        int lineGap = 8;

        int panelX = Screen.GetWidth() - panelWidth - margin;
        int panelY = margin;

        int titleX = panelX + panelWidth - padding - font.StringWidth(titleText);
        int missionX = panelX + panelWidth - padding - font.StringWidth(missionText);
        int statusX = panelX + panelWidth - padding - font.StringWidth(statusText);
        int progressX = panelX + panelWidth - padding - font.StringWidth(progressText);
        int phaseX = panelX + panelWidth - padding - font.StringWidth(phaseText);

        int titleY = panelY + padding;
        int missionY = titleY + font.GetHeight() + lineGap;
        int statusY = missionY + font.GetHeight() + lineGap;
        int progressY = statusY + font.GetHeight() + lineGap;
        int phaseY = progressY + font.GetHeight() + lineGap;

        Screen.Clear(
            panelX,
            panelY,
            panelX + panelWidth,
            panelY + panelHeight,
            Color(196, 207, 163)
        );

        Screen.DrawLine(panelX, panelY, panelX + panelWidth, panelY, Color(0, 0, 0));
        Screen.DrawLine(panelX, panelY + panelHeight, panelX + panelWidth, panelY + panelHeight, Color(0, 0, 0));
        Screen.DrawLine(panelX, panelY, panelX, panelY + panelHeight, Color(0, 0, 0));
        Screen.DrawLine(panelX + panelWidth, panelY, panelX + panelWidth, panelY + panelHeight, Color(0, 0, 0));

        Screen.DrawText(font, black, titleX, titleY, titleText);
        Screen.DrawText(font, black, missionX, missionY, missionText);
        Screen.DrawText(font, black, statusX, statusY, statusText);
        Screen.DrawText(font, black, progressX, progressY, progressText);
        Screen.DrawText(font, black, phaseX, phaseY, phaseText);
    }
}